This library adds Multicast DNS (aka Bonjour) capability to the Couchbase Lite Listener via an IServiceBrowser / IRegisterService implementation.  Here is a breakdown of the files included:

Couchbase.Lite.Listener.Bonjour.dll - The Windows standalone implementation (based around dnssd.dll).
iOS/Couchbase.Lite.Listener.Bonjour.dll - The iOS *and Mac OS X* implementation (based around libc.dylib)
Android/Couchbase.Lite.Listener.Bonjour.dll - The Android implementation (based around libmdnsd.so)

Note that so far I have noticed that if you include the Windows version in an OS X editor, it will attempt to use that one and fail for reasons unknown (at least in the editor).

I've included SHA1 checksums for each file.  You can verify all the files' integrity by running this *nix command:
shasum -c checksums.txt
